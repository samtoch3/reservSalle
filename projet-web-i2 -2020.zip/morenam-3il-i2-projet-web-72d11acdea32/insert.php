<?php
session_start();

$ine = $_SESSION['ine'];
$Date = $_POST['Madat'];
$heure_deb = $_POST['heure_deb'];
$heure_fin = $_POST['heure_fin'];
$numSalle = $_POST['numSalle'];
 

if (isset($Date) && isset($heure_deb) && isset($heure_fin) && isset($numSalle)) {
  if ($heure_deb == '08:30' && $heure_fin == '10:00') {
    $idcre = 1;
  } elseif ($heure_deb == '10:30' && $heure_fin == '12:00') {
    $idcre = 2;
  } elseif ($heure_deb == '13:30' && $heure_fin == '15:00') {
    $idcre = 3;
  } elseif ($heure_deb == '15:15' && $heure_fin == '16:45') {
    $idcre = 4;
  } elseif ($heure_deb == '17:00' && $heure_fin == '18:30') {
    $idcre = 5;
  } else {

?>
    <script>
      alert('Entrer le bon creneau. Pour info, il y a 5 creneaux à 3iL');
    </script>
    <?php
    header('Location:reservation.php');
  }
  try {
    $bd = new PDO("mysql:host=localhost;dbname=3ilreservsalle;charset=utf8", "root", "");
    $bd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $req=$bd->prepare('select (salle.nbplacetot- count(*)) as nb from creneau natural join salle inner join 
    creneau3il on creneau.idc=creneau3il.id where creneau.idc=:idc and salle.numsalle=:numsalle and creneau.Madat=:madat');
    $req->bindParam(':idc',$idcre);
    $req->bindParam(':numsalle',$numSalle);
    $req->bindParam(':madat',$Date);
    $req->execute();
    $result=$req->fetch();
        if ($result['nb']>0) {

      //if (isset($pDispo>0)){}
      $sql = $bd->query("INSERT INTO creneau(Madat, idc, INE ,numSalle) VALUES('" . $Date . "','" . $idcre . "','" . $ine . "','" . $numSalle . "')");

        header('Location:accueil.php?key='.$_SESSION['token']);
    
    } else {
    ?>  
      <script>
        alert('RESERVATION IMPOSSIBLE : Pour cette salle, toutes les creneaux sont occupés !');
      </script>
<?php

    }
  } catch (Exception $err) {
    echo $err;
  }
}
?>