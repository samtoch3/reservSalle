<?php
session_start();
//$tableau = $_SESSION["tableau"];
$pass = $_POST["pass"];

/*for ($i=0; $i<strlen($pass); $i++){
        echo $tableau[convert($pass[$i])];
    }
    function convert ( $lettre ) {
        $tab = array("A" => "0","B" => "1","C" => "2","D" => "3","E" => "4","F" => "5","G" => "6","H" => "7","I" => "8","J" => "9",);
        $lettre = strtr("$lettre", $tab);
        return $lettre;
    }*/

if ($_SESSION['mdpNum'] == $pass) {
    if ($_SESSION['bool'] == 1) {
        header('Location:accueil.php?key='.$_SESSION['token']);
    } elseif ($_SESSION['bool'] == 0) {
        header('Location:accueiladmin.php?key='.$_SESSION['token']);
    } else {
?>
        <br /><br /><br /><br /><br />
        <center>
            <p class="error"><b>
                    <font size="40px">L'authentification a échoué<br /></font>
                </b></p>
        </center><?php
                }
            } else {
                    ?>
    <br /><br /><br /><br /><br />
    <center>
        <p class="error"><b>
                <font size="40px">L'authentification a échoué<br /></font>
            </b></p>
    </center><?php
            }



            /* try{

        $connect = new PDO("mysql:host=localhost;dbname=reservsalle;charset=utf8","root","");
        $connect->setAttribute(PDO:: ATTR_ERRMODE, PDO:: ERRMODE_EXCEPTION);

        $sql = $connect->query("SELECT * FROM user WHERE mdpNum='".$pass."'");
        $sql->bindParam(1, $pass, PDO::PARAM_STR);

        $sql->execute();
        
       if($result = $sql->fetch()){
          //if (password_verify($pass, $result['PassHash'])) {
            if($result['droits']=='admin'){
                if($stay==true){
                    $_SESSION['logn'] = $_POST["logn"];
                   
                    setcookie('logn', $_SESSION['logn'], time() + 365*24*3600, '/', 'http://localhost/projet-web%20i2/3il-i2-projet-web/accueil.php', false, true);
                }
                $_SESSION['prenom'] = $result['prenom'];
                header('Location: accueiladmin.php');
            }
            if($result['droits']=="etudiant"){
                if($stay==true){
                    $_SESSION['logn'] = $_POST["logn"];
                   
                    setcookie('logn', $_SESSION['logn'], time() + 365*24*3600,'/', 'http://localhost/projet-web%20i2/3il-i2-projet-web/accueiladmin.php', false, true);
                }
                $_SESSION['ine'] = $result['INE'];
                $_SESSION['nom'] = $result['Nom'];
                $_SESSION['prenom'] = $result['Prenom'];
                $_SESSION['login'] = $result['Login'];
                header('Location: accueil.php');
            }
            
          }
          else
        {
            ?>
            <br/><br/><br/><br/><br/><center><p class="error"><b><font size="40px">L'authentification a échoué<br/></font></b></p></center><?php
        }
       }    
        else
        {
            ?>
            <br/><br/><br/><br/><br/><center><p class="error"><b><font size="40px">L'authentification a échoué<br/></font></b></p></center><?php
        }
    
    }catch(PDOException $err){
        echo $err;
    }*/
                ?>