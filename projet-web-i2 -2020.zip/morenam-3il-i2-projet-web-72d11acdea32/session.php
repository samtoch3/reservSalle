<?php
session_start();
$pass = $_POST["pass"];
$logn = $_POST["logn"];
$token = $_POST['token'];


try {

    $connect = new PDO("mysql:host=localhost;dbname=3ilreservsalle;charset=utf8", "root", "");
    $connect->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    //$sql = $connect->query("SELECT * FROM user WHERE login='".$logn."'");
    $sql = $connect->prepare("SELECT * FROM user WHERE login='" . $logn . "'");
    $sql->bindParam(1, $logn, PDO::PARAM_STR);

    $sql->execute();

    if ($result = $sql->fetch()) {
        if (password_verify($pass, $result['PassHash'])) {
            $_SESSION['token'] = $token;
            if ($result['droits'] == 'admin') {
                if ($stay == true) {
                    $_SESSION['logn'] = $_POST["logn"];
                    //$_SESSION['mdpNum'] = $result['mdpNum'];
                    setcookie('logn', $_SESSION['logn'], time() + 365 * 24 * 3600, '/', 'http://localhost/projet-web%20i2/3il-i2-projet-web/accueil.php', false, true);
                }
                $_SESSION['mdpNum'] = $result['mdpNum'];
                $_SESSION['bool'] = 0;
                $_SESSION['prenom'] = $result['Prenom'];
                header('Location:authentification.php?key='.$_SESSION['token']);
            }
            if ($result['droits'] == "etudiant") {

                if ($stay == true) {
                    $_SESSION['logn'] = $_POST["logn"];

                    setcookie('logn', $_SESSION['logn'], time() + 365 * 24 * 3600, '/', 'http://localhost/projet-web%20i2/3il-i2-projet-web/accueiladmin.php', false, true);
                }
                $_SESSION['ine'] = $result['INE'];
                $_SESSION['nom'] = $result['Nom'];
                $_SESSION['prenom'] = $result['Prenom'];
                $_SESSION['login'] = $result['Login'];
                $_SESSION['mdpNum'] = $result['mdpNum'];
                $_SESSION['bool'] = 1;


                header('Location:authentification.php?key='.$_SESSION['token']);
            }
        } else {
?>
            <br /><br /><br /><br /><br />
            <center>
                <p class="error"><b>
                        <font size="40px">Identifiants Incorrects <br /></font>
                        <font size="20px">(Pour tout problème, veuillez contacter l'administrateur)</font>
                    </b></p>
            </center><?php
                    }
                } else {
                        ?>
        <br /><br /><br /><br /><br />
        <center>
            <p class="error"><b>
                    <font size="40px">Identifiants Incorrects <br /></font>
                    <font size="20px">(Pour tout problème, veuillez contacter l'administrateur)</font>
                </b></p>
        </center><?php
                }
            } catch (PDOException $err) {
                echo $err;
            }
                    ?>