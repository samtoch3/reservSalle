<!DOCTYPE html>
<html lang="fr" dir="ltr" translate="no" data-environment="production">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <meta name="description" content="Authentification du 1er niveau">
  <meta name="keywords" content="Authentification sécurisée">

  <title>Salles'Reserv. - Connexion</title>

  <link rel="shortcut icon" href="pics/pic3.png">
  <link rel="stylesheet" href="frameworks/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="frameworks/fontawesome-free/css/all.min.css">
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="web/Dev web -bootstrap 4.3.1/bootstrap-4.3.1-dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="fonts/font-awesome.min.css">
  <style>
    body {
      font-family: Arial, Helvetica, sans-serif;
    }

    /* Full-width input fields */
  </style>
</head>

<body>
  <header>
    <nav class="navbar navbar-expand-md navbar-dark navbar-right fixed-top">
      <!-- Logo -->
      <a class="navbar-brand" href="index.php" target="_self">
        <img src="pics/pic1.png" alt="Accueil" title="Accueil" width="110px" height="65px">
      </a>

      <!-- Toggler/collapsibe Button -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>

      <!-- Navbar links -->
      <div class="collapse navbar-collapse" id="collapsibleNavbar">
        <ul class="navbar-nav justify-content-end">
          <li class="nav-item">
            <a class="nav-link" href="#" target="_self">
              <i class="fas fa-home"></i>
              Accueil</a>
          </li>

          <li class="nav-item active">
            <a class="nav-link">
              <i class="fas fa-user"></i>
              Connexion</a>
          </li>
        </ul>
      </div>
      <h2 class="text-theme-colored-white font-26"><b>#HERE-WE-LEARN - #HERE-WE-CODE - #UPGRADE-YOUR-SELF</b></h2>
    </nav>
  </header>

  <section>
    <div class="jumbotron jumbotron-fluid">
      <div class="container">
        <div class="row">
          <div class="col-md-6 col-md-push-3">
            <br>
            <h4 class="text-gray mt-0 pt-5" align="center"> Connexion</h4>
            <hr>
            <form name="login-form" class="clearfix" action="session.php" method="post">
              <!--<input name="token" value="03111999">-->
              <input type="hidden" name="token" value="<?=bin2hex(openssl_random_pseudo_bytes(8))?>">
              <div class="row">
                <div class="form-group col-md-12">
                  <label for="username">Login : </label>
                  <input id="username" name="logn" class="form-control" type="text" required />
                </div>
              </div>
              <div class="row">
                <div class="form-group col-md-12">
                  <label for="password">Mot de passe : </label>
                  <input id="password" name="pass" class="form-control" type="password" required />
                </div>
              </div>

              <div class="form-group pull-right mt-10">
                <button type="submit" class="btn btn-dark btn-sm">Connexion</button>
              </div>
              <div class="clear text-center pt-10">
                <a class="text-theme-colored font-weight-600 font-12" href="newmdp.php">Mot de passe oublié ?</a>
              </div>

            </form>
            <br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
          </div>
        </div>
      </div>
    </div>
  </section>

  <footer id="footer" class="fixed-bottom">
    <a href="#">A propos de nous</a> |
    <a href="#">Guide & Assistance</a> |
    <a href="#">Laissez nous un commentaire !</a>
    <p style="text-align:center !important;">
      <a href="#">Mentions Légales</a> - © Sept 2020 - <a href="#">Politique & confidentialité</a>
      <div class="footer-items-groups">
        <div class="footer-items">
          <a href="https://www.facebook.com"><i class="fab fa-facebook-f" class="footer-item"></i></a>
          <a href="https://www.twitter.com"><i class="fab fa-twitter" class="footer-item"></i></a>
          <a href="https://www.youtube.com"><i class="fab fa-youtube" class="footer-item"></i></a>
          <a href="https://www.instagram.com"><i class="fab fa-instagram" class="footer-item"></i></a>
          <a href="https://www.google.com"><i class="fab fa-google" class="footer-item"></i></a>
          <a href="https://www.pinterest.com"><i class="fab fa-pinterest" class="footer-item"></i></a>
          <a href="https://www.linkedin.com"><i class="fab fa-linkedin" class="footer-item"></i></a>
          <a href="https://www.whatsapp.com"><i class="fab fa-whatsapp" class="footer-item"></i></a>
        </div>
      </div>
    </p>
  </footer>
</body>

</html>