<?php
try {
  $bd = new PDO("mysql:host=localhost;dbname=3ilreservsalle;charset=utf8", "root", "");
  $bd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (Exception $e) {
  echo $e->getMessage();
}


$req = $bd->prepare("DELETE FROM creneau where ine =:ine AND idc=:id_creneau AND Madat=:madat AND numSalle=:numSalle");
$req->bindParam(":ine", $_GET['ine']);
$req->bindParam(":madat", $_GET['madat']);
$req->bindParam(":numSalle", $_GET['numSalle']);
$req->bindParam(":id_creneau", $_GET['id_creneau']);
$req->execute();

echo $_GET['id'];

?>
