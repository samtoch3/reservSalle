<?php
session_start();
try{
    $bd = new PDO("mysql:host=localhost;dbname=3ilreservsalle;charset=utf8","root","");
    $bd->setAttribute(PDO:: ATTR_ERRMODE, PDO:: ERRMODE_EXCEPTION);
}catch(Exception $e){
  echo $e->getMessage();
}
$req=$bd->query('select *,(salle.nbPlaceTot-(SELECT COUNT(*) FROM creneau WHERE creneau.idc=creneau3il.Id AND creneau.numSalle=salle.numSalle )) place FROM disponibilite INNER JOIN salle on salle.numSalle=disponibilite.id_s INNER join creneau3il on disponibilite.Id_cr=creneau3il.Id order by numsalle');
$data=$req->fetchAll(PDO::FETCH_ASSOC);
if(isset($_POST['date'])){
    $req=$bd->prepare('select *,(salle.nbPlaceTot-(SELECT COUNT(*) FROM creneau WHERE creneau.idc=creneau3il.Id AND creneau.numSalle=salle.numSalle and creneau.madat=:madat )) place FROM disponibilite INNER JOIN salle on salle.numSalle=disponibilite.id_s INNER join creneau3il on disponibilite.Id_cr=creneau3il.Id order by numsalle');
    $req->bindParam(':madat',$_POST['date']);
    $req->execute();
    $data=$req->fetchAll(PDO::FETCH_ASSOC);
}
?>


<!DOCTYPE html>
<html lang="fr" dir="ltr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <meta name="description" content="Connexion à votre compte unepetition.fr petition en ligne gratuite ">
    <meta name="keywords" content="creer petition, petition, lancer petition, petition du web, je signe, je lance, une petition ">

    <title>Salles'Reserv. - Planning des salles</title>

    <link rel="shortcut icon" href="pics/pic3.png">
    <link rel="stylesheet" href="frameworks/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="frameworks/fontawesome-free/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="web/Dev web -bootstrap 4.3.1/bootstrap-4.3.1-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="fonts/font-awesome.min.css">
    <style>
        body {
            font-family: Arial, Helvetica, sans-serif;
        }

        /* Full-width input fields */
    </style>
</head>

<body>
    <header>
        <nav class="navbar navbar-expand-md navbar-dark navbar-right fixed-top">
            <!-- Logo -->
            <a class="navbar-brand" href="accueil.php">
                <img src="pics/pic1.png" alt="Accueil" title="Accueil" width="110px" height="65px">
            </a>

            <!-- Toggler/collapsibe Button -->
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- Navbar links -->
            <div class="collapse navbar-collapse" id="collapsibleNavbar">
                <ul class="navbar-nav justify-content-end">
                    <li class="nav-item">
                        <a class="nav-link" href="accueil.php">
                            <i class="fas fa-home"></i>
                            Accueil</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reservation.php">
                            <i class="fas fa-edit"></i>
                            Reserver une salle</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="viewReservation.php">
                            <i class="fas fa-clone"></i>
                            Voir mes reservation</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="planningSalle.php">
                            <i class="fas fa-list"></i>
                            Planning des salles LS</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" onclick="document.getElementById('id01').style.display='block'" style="width:auto;">
                            <i class="fas fa-user"></i>
                            Mon profil</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="deconnect.php">
                            <i class="fas fa-sign-out-alt"></i>
                            Se deconnecter</a>
                    </li>
                </ul>
            </div>
            <i class="nav-link">
                <h2 class="text-theme-colored-white font-20">Bonjour <b><?php echo $_SESSION['prenom'] ?></b>.</h2>
            </i>
        </nav>
    </header>
    <section>
    <div class="jumbotron jumbotron-fluid">  
      <div class="container">
        <div class="row">
          <div class="col-md-6 col-md-push-3">
              <br>
            <h4 class="text-gray mt-0 pt-5" align="center">Planning des Salles</h4>
            <hr>
            <div>
            <form method="post">
            <input type="date" name="date"><br>
            <input type="submit" value="confirmer">
            </form>
            </div>
            <table class="table table-border">
            <tr>
            <th>Numero Salle</th>
            <th>Numero créneau</th>
            <th>Heure debut</th>
            <th>Heure fin</th>
            <th>Place Disponible</th>
            <th></th>
            </tr>
            <?php
            foreach($data as $val){

            ?>
            <tr>
            <td><?=$val['id_s']?></td>
            <td><?=$val['Id']?></td>
            <td><?=$val['heure_deb']?></td>
            <td><?=$val['heure_fin']?></td>
            <td><?=$val['place']?></td>
            <td><?php if($val['place']>0){
            echo'<button type="button" disabled>disponible</button>';}
            else{
                echo'<button type="button" disabled>indisponible</button>';
            }?></td>
            </tr>
            <?php
            }
            ?>
            </table>
		
        
        
          </div>
        </div>
      </div>
    </div>
</section>

    <section>
        <div class="jumbotron jumbotron-fluid">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-md-push-3">
                        <br>
                        <h4 class="text-gray mt-0 pt-5" align="center">Planning des Salles</h4>
                        <hr>



                    </div>
                </div>
            </div>
        </div>
    </section>

    <section>
        <div id="id01" class="modal">

            <form class="modal-content animate" action="#" method="POST">
                <div class="imgcontainer">
                    <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Quitter">&times;</span>
                </div>

                <div class="container">
                    <div>
                        <br />
                        <table>
                            <tr>
                                <td align="right" width="50%" colsspan="2"><img src="pics/pic4.png" width="100px" height="100px"></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td><b>INE : </b></td>
                                <td><b> D87U3iLi2E00<?php echo $_SESSION['ine'] ?></b></td>
                            </tr>
                            <tr>
                                <td><b>Prenom : </b></td>
                                <td><b> <?php echo $_SESSION['prenom'] ?></b></td>
                            </tr>
                            <tr>
                                <td><b>Nom : </b></td>
                                <td><b> <?php echo $_SESSION['nom'] ?></b></td>
                            </tr>
                            <tr>
                                <td><b>Login : </b></td>
                                <td><b> <?php echo $_SESSION['login'] ?>@3il.fr</b></td>
                            </tr>
                        </table>
                    </div>
            </form>
        </div>



        <script>
            // Get the modal
            var modal = document.getElementById('id01');

            // When the user clicks anywhere outside of the modal, close it
            window.onclick = function(event) {
                if (event.target == modal) {
                    modal.style.display = "none";
                }
            }
        </script>
    </section>

    <footer id="footer" class="fixed-bottom">
        <a href="#">A propos de nous</a> |
        <a href="#">Guide & Assistance</a> |
        <a href="#">Laissez nous un commentaire !</a>
        <p style="text-align:center !important;">
            <a href="#">Mentions Légales</a> - © Sept 2020 - <a href="#">Politique & confidentialité</a>
            <div class="footer-items-groups">
                <div class="footer-items">
                    <a href="https://www.facebook.com"><i class="fab fa-facebook-f" class="footer-item"></i></a>
                    <a href="https://www.twitter.com"><i class="fab fa-twitter" class="footer-item"></i></a>
                    <a href="https://www.youtube.com"><i class="fab fa-youtube" class="footer-item"></i></a>
                    <a href="https://www.instagram.com"><i class="fab fa-instagram" class="footer-item"></i></a>
                    <a href="https://www.google.com"><i class="fab fa-google" class="footer-item"></i></a>
                    <a href="https://www.pinterest.com"><i class="fab fa-pinterest" class="footer-item"></i></a>
                    <a href="https://www.linkedin.com"><i class="fab fa-linkedin" class="footer-item"></i></a>
                    <a href="https://www.whatsapp.com"><i class="fab fa-whatsapp" class="footer-item"></i></a>
                </div>
            </div>
        </p>
    </footer>
</body>

</html>