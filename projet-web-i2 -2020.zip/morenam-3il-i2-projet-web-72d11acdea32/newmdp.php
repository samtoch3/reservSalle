<!DOCTYPE html>
<html lang="fr" dir="ltr">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>Salles'Reserv. - mot de passe oublié</title>
        <link rel="shortcut icon" href="pics/pic3.png">
        <link rel="stylesheet" href="frameworks/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="frameworks/fontawesome-free/css/all.min.css">
        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="web/Dev web -bootstrap 4.3.1/bootstrap-4.3.1-dist/css/bootstrap.min.css">
       
        <style>
        body {font-family: Arial, Helvetica, sans-serif;}

        
        </style>
        </head>
    <body>
        <header>
            <nav class="navbar navbar-expand-md navbar-dark navbar-right fixed-top">
                <!-- Logo -->
                <a class="navbar-brand" href="index.php">
                    <img src="pics/pic1.png" alt="Accueil" title="Accueil" width="110px" height="65px">
                </a>

                <!-- Toggler/collapsibe Button -->
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
                    <span class="navbar-toggler-icon"></span>
                </button>
  <!-- Navbar links -->
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
                    <ul class="navbar-nav justify-content-end">
                        <li class="nav-item active">
                            <a class="nav-link" href="index.php">
                                <i class="fas fa-home"></i>
                                Accueil</a>
                        </li>
                    </ul>
                </div> 
                
            </nav>
        </header>
        <section>
    <div class="jumbotron jumbotron-fluid">  
      <div class="container">
        <div class="row">
          <div class="col-md-6 col-md-push-3">
              <br>
            <h4 class="text-gray mt-0 pt-5" align="center"> Modifier le mot de passe</h4>
            <hr>
            <form name="login-form" class="clearfix" action="sess.php" method="post">
              <!--<input name="token" value="03111999">-->
              <input type="hidden" name="token" value="03111999ab834ec23bb3d43abb05ac4ee12331aab7589fc1">
              <div class="row">
                <div class="form-group col-md-12">
                  <label for="username">Votre INE : </label>
                  <input id="username" name="logn" class="form-control" type="text" required />
                </div>
              </div>
              <div class="row">
                <div class="form-group col-md-12">
                  <label for="password">Nouveau mot de passe : </label>
                  <input id="password" name="pass" class="form-control" type="password" required />
                </div>
              </div>

              <div class="form-group pull-right mt-10">
                <button type="submit" align="right" class="btn btn-dark btn-sm">Modifier le mot de passe</button>
              </div>

            </form>
            <br /><br /><br /><br /><br /><br /><br /><br /><br />
          </div>
        </div>
      </div>
    </div>
</section>
        <footer id="footer" class="fixed-bottom">
             <a href="#">A propos de nous</a> |
             <a href="#">Guide & Assistance</a> | 
             <a href="#">Laissez nous un commentaire !</a>
            <p style="text-align:center !important;">
                <a href="#">Mentions Légales</a> - © Sept 2020 - <a href="#">Politique & confidentialité</a>
            
                    <div class="footer-items-groups">
                        <div class="footer-items">
                            <a href="https://www.facebook.com"><i class="fab fa-facebook-f" class="footer-item"></i></a>
                            <a href="https://www.twiter.com"><i class="fab fa-twitter" class="footer-item"></i></a>
                            <a href="https://www.youtube.com"><i class="fab fa-youtube" class="footer-item"></i></a>
                            <a href="https://www.instagram.com"><i class="fab fa-instagram" class="footer-item"></i></a>
                            <a href="https://www.google.com"><i class="fab fa-google" class="footer-item"></i></a>
                            <a href="https://www.pinterest.com"><i class="fab fa-pinterest" class="footer-item"></i></a>
                            <a href="https://www.linkedin.com"><i class="fab fa-linkedin" class="footer-item"></i></a>
                            <a href="https://www.whatsapp.com"><i class="fab fa-whatsapp" class="footer-item"></i></a>
                        </div>
                    </div>
                    </p>
        </footer>