<?php
session_start();

?>


<!DOCTYPE html>
<html lang="fr" dir="ltr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Salles'Reserv. - Administrateur</title>
    <link rel="shortcut icon" href="pics/0.png">
    <link rel="stylesheet" href="frameworks/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="frameworks/fontawesome-free/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="web/Dev web -bootstrap 4.3.1/bootstrap-4.3.1-dist/css/bootstrap.min.css">

    <style>
        body {
            font-family: Arial, Helvetica, sans-serif;
        }

        /* Full-width input fields */
    </style>
</head>

<body>
    <header>
        <nav class="navbar navbar-expand-md navbar-dark navbar-right fixed-top">
            <!-- Logo -->
            <a class="navbar-brand" href="accueil.php">
                <img src="pics/pic1.png" alt="Accueil" title="Accueil" width="110px" height="65px">
                <img src="pics/0.png" alt="Accueil" title="Accueil" width="40px" height="35px">
            </a>

            <!-- Toggler/collapsibe Button -->
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- Navbar links -->
            <div class="collapse navbar-collapse" id="collapsibleNavbar">
                <ul class="navbar-nav justify-content-end">
                    <li class="nav-item">
                        <a class="nav-link" href="accueiladmin.php">
                            <i class="fas fa-home"></i>
                            Accueil</a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="listetreserv.php">
                            <i class="fas fa-sign-in-alt"></i>
                            Liste des étudiants ayant effectué(e)s une reservation</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="listesallesresrv.php">
                            <i class="fas fa-clone"></i>
                            Liste des salles reservées</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="listesalles.php">
                            <i class="fas fa-list"></i>
                            Liste de toutes les salles LS</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="listeetudiant.php">
                            <i class="fas fa-user"></i>
                            Liste des étudiants</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="deconnect.php">
                            <i class="fas fa-sign-out-alt"></i>
                            Se deconnecter</a>
                    </li>
                </ul>
            </div>
            <i class="nav-link">
                <h2 class="text-theme-colored-white font-20">Bonjour <b><?php echo $_SESSION['prenom'] ?></b>.</h2>
            </i>
        </nav>
    </header>

    <section>
        <div class="jumbotron jumbotron-fluid">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-md-push-3">
                        <br>
                        <h4 class="text-gray mt-0 pt-5" align="center"> Liste de étudiants</h4>
                        <hr>

                        <table class=table table-bordered>
                            <tr>
                                <th>INE</th>
                                <th>Nom</th>
                                <th>Prénom</th>
                                <th>Login</th>
                                <th>Nombre de reservation</th>
                            </tr>

                            <?php
                            try {
                                $bd = new PDO("mysql:host=localhost;dbname=3ilreservsalle;charset=utf8", "root", "");
                                $bd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                                //$req1 = $bd->query("SELECT u.INE, Nom, Prenom, u.Login, COUNT(c.Id) AS nbResv FROM user u, creneau c, reservation r WHERE u.INE=r.INE AND c.Id=r.Id_Creneau AND droits='etudiant' ORDER BY u.INE ASC;");

                                $req1 = $bd->query("SELECT u.INE, Nom, Prenom, u.Login, COUNT(r.INE) AS nbResv FROM user u, creneau r WHERE u.INE=r.INE AND droits='etudiant' GROUP BY nom");                                $don = $req1->fetchAll();

                                //var_dump ($don);

                                foreach ($don as $val) {
                                    echo "<tr id=\"" . $val['INE'] . "\"><td>" . $val['INE'] . "</td><td>" . $val['Nom'] . "</td><td>" . $val['Prenom'] . "</td><td>" . $val['Login'] . "</td><td>" . $val['nbResv'] . "</td></tr>";
                                }
                            } catch (Exception $e) {
                                echo $e;
                            }
                            ?>

                        </table>

                    </div>
                </div>
            </div>
        </div>
    </section>


    <footer id="footer" class="fixed-bottom">
        <a href="#">A propos de nous</a> |
        <a href="#">Guide & Assistance</a> |
        <a href="#">Laissez nous un commentaire !</a>
        <p style="text-align:center !important;">
            <a href="#">Mentions Légales</a> - © Sept 2020 - <a href="#">Politique & confidentialité</a>

            <div class="footer-items-groups">
                <div class="footer-items">
                    <a href="https://www.facebook.com"><i class="fab fa-facebook-f" class="footer-item"></i></a>
                    <a href="https://www.twiter.com"><i class="fab fa-twitter" class="footer-item"></i></a>
                    <a href="https://www.youtube.com"><i class="fab fa-youtube" class="footer-item"></i></a>
                    <a href="https://www.instagram.com"><i class="fab fa-instagram" class="footer-item"></i></a>
                    <a href="https://www.google.com"><i class="fab fa-google" class="footer-item"></i></a>
                    <a href="https://www.pinterest.com"><i class="fab fa-pinterest" class="footer-item"></i></a>
                    <a href="https://www.linkedin.com"><i class="fab fa-linkedin" class="footer-item"></i></a>
                    <a href="https://www.whatsapp.com"><i class="fab fa-whatsapp" class="footer-item"></i></a>
                </div>
            </div>
        </p>
    </footer>
    <script src="frameworks/jquery/jquery.min.js"></script>

    <script src="frameworks/bootstrap/js/bootstrap.bundle.min.js"></script>

    <script src="frameworks/jquery-easing/jquery.easing.min.js"></script>
</body>

</html>