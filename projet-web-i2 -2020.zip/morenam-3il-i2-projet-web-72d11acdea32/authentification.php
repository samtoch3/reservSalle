<?php
session_start();

if($_GET['key']==$_SESSION['token']){


?>

<html xml:lang="fr" lang="fr">

<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8">
	<title>Salles'Reserv. - Authentification sécurisée</title>
	<meta name="description" content="Authentification sécurisée du 2eme niveau" />
	<meta name="robots" content="index,follow" />
	<meta http-equiv="content-language" content="fr" />
	<link rel="shortcut icon" href="pics/pic3.png">
	<link href='styles.css' rel='stylesheet' type='text/css' />
	<script language="Javascript" src="fichJS.js"></script>
</head>

<body>

	<div class="div_conteneur_parent">
		<div class="div_conteneur_page">
			<div class="div_int_page">

				<div class="div_saut_ligne" style="height:40px;">
				</div>

				<div style="float:left;width:10%;height:40px;"></div>
				<div style="float:left;width:80%;height:40px;text-align:center;">
					<div style="width:auto;display:block;height:auto;text-align:center;background-color:#ccccff;border:#7030a0 1px solid;padding-top:12px;box-shadow: 6px 6px 0px #aaa;color:#7030a0;">

						<table width="100%">
							<tr>
								<td align="left" width="10%"> <img src="pics/pic1.png" alt="Accueil" title="Accueil" width="100px" height="65px"></td>
								<td align="center" width="90%">
									<h1> Authentification Sécurisée</h1>
								</td>
							</tr>
						</table>

					</div>
				</div>

				<div style="float:left;width:10%;height:40px;"></div>

				<div class="div_saut_ligne">
				</div>

				<div style="width:100%;height:auto;text-align:center;">

					<div style="width:800px;display:inline-block;" id="conteneur">

						<div class="centre">
							<div class="titre_centre" id="titre" style="text-align:left;padding-left:10px;">
								<p align="center">Veuillez saisir votre identifiant secret à l'aide du pavé numérique virtuel.</p>
							</div>
						</div>

						<form name="authentif-form" class="clearfix" action="sessionAuthentif.php" method="post">
							<input type="hidden" name="token" value="03111999ab834ec23bb3d43abb05ac4ee12331aab7589fc1">
							<div class="colonne" id="liste">
								<label for="password">Votre identifiant : </label>
								<input id="pass" name="pass" class="form-control" type="password" maxlength="6" value="" readOnly required />

								<div id="grille" style="align:center;margin-left:207px;margin-top:20px;">
									<div class="case" id="case0"></div>
									<div class="case" id="case1"></div>
									<div class="case" id="case2"></div>
									<div class="case" id="case3"></div>
									<div class="case" id="case4"></div>
									<div class="case" id="case5"></div>
									<div class="case" id="case6"></div>
									<div class="case" id="case7"></div>
									<div class="case" id="case8"></div>
									<div class="case" id="case9"></div>
									<div class="case" id="case10"></div>
									<div class="case" id="case11"></div>
									<?php //$pass = password_hash(pass, PASSWORD_DEFAULT)
									?>
									<input type="submit" class="bouton" value="Valider" style="align:center;margin-top:30px;" />
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>

</body>
<script type="text/javascript" language="javascript">
	generation();

	function bloc(lettre) {
		if (document.formulaire.motdepasse.value.length < 8)
			document.formulaire.motdepasse.value = document.formulaire.motdepasse.value + lettre;
	}

	function generation() {
		var nb_alea;
		var let_alea;
		var test = true;
		var chaine = '';

		purger();

		for (var i = 0; i < 10; i++) {
			while (test == true) {
				nb_alea = Math.floor(Math.random() * 12);
				if (chaine.indexOf('-' + nb_alea + '-') > -1)
					nb_alea = Math.floor(Math.random() * 12);
				else {
					document.getElementById('case' + nb_alea).innerHTML = "<input type='button' class='btn' value='" + i + "'onClick='document.getElementById(\"pass\").value += " + i + "' />";
					chaine += '-' + nb_alea + '-';
					test = false;
				}
			}
			test = true;
		}
	}

	function purger() {
		for (var i = 0; i < 12; i++) {
			document.getElementById('case' + i).innerHTML = '';
		}
		document.getElementById('pass').value = '';
	}

	function validation() {
		var combinaison = id_mp().split('|');
		var ident = combinaison[0];
		var mp = combinaison[1];

		if (document.getElementById('identifiant').value.toLowerCase() == ident.toLowerCase() && document.getElementById('pass').value == mp)
			document.getElementById('apercu').innerText = 'Vous êtes désormais connecté';
		else
			document.getElementById('apercu').innerText = 'L\'authentification a échoué';
	}
</script>

</html>

<?php } else {
	header('Location:index.php');
}
?>