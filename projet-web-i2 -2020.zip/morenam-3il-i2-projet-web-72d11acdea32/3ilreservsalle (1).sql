-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  jeu. 05 nov. 2020 à 01:56
-- Version du serveur :  10.4.6-MariaDB
-- Version de PHP :  7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `3ilreservsalle`
--

-- --------------------------------------------------------

--
-- Structure de la table `creneau`
--

CREATE TABLE `creneau` (
  `Madat` date NOT NULL,
  `idc` int(11) NOT NULL,
  `INE` int(11) NOT NULL,
  `numSalle` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `creneau`
--

INSERT INTO `creneau` (`Madat`, `idc`, `INE`, `numSalle`) VALUES
('2020-11-06', 2, 2, 103),
('2020-11-07', 1, 2, 105),
('2020-11-07', 3, 2, 104),
('2020-11-20', 1, 2, 111);

-- --------------------------------------------------------

--
-- Structure de la table `creneau3il`
--

CREATE TABLE `creneau3il` (
  `Id` int(11) NOT NULL,
  `heure_deb` time NOT NULL,
  `heure_fin` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `creneau3il`
--

INSERT INTO `creneau3il` (`Id`, `heure_deb`, `heure_fin`) VALUES
(1, '08:30:00', '10:00:00'),
(2, '10:30:00', '12:00:00'),
(3, '13:30:00', '15:00:00'),
(4, '15:15:00', '16:45:00'),
(5, '17:00:00', '18:30:00');

-- --------------------------------------------------------

--
-- Structure de la table `disponibilite`
--

CREATE TABLE `disponibilite` (
  `Id_cr` int(11) NOT NULL,
  `id_s` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `disponibilite`
--

INSERT INTO `disponibilite` (`Id_cr`, `id_s`) VALUES
(1, 101),
(2, 101),
(3, 101),
(4, 101),
(5, 101),
(1, 102),
(2, 102),
(3, 102),
(4, 102),
(5, 102),
(1, 103),
(2, 103),
(3, 103),
(4, 103),
(5, 103),
(1, 104),
(2, 104),
(3, 104),
(4, 104),
(5, 104),
(1, 105),
(2, 105),
(2, 106),
(3, 105),
(4, 105),
(5, 105),
(1, 106),
(3, 106),
(4, 106),
(5, 106),
(1, 107),
(3, 107),
(2, 107),
(4, 107),
(5, 107),
(1, 108),
(3, 108),
(2, 108),
(4, 108),
(5, 108),
(1, 109),
(3, 109),
(2, 109),
(4, 109),
(5, 109),
(1, 110),
(3, 110),
(2, 110),
(4, 110),
(5, 110),
(1, 111),
(3, 111),
(2, 111),
(4, 111),
(5, 111),
(1, 112),
(3, 112),
(2, 112),
(4, 112),
(5, 112),
(1, 201),
(3, 201),
(2, 201),
(4, 201),
(5, 201),
(1, 202),
(3, 202),
(2, 202),
(4, 202),
(5, 202),
(1, 203),
(3, 203),
(2, 203),
(4, 203),
(5, 203),
(1, 204),
(3, 204),
(2, 204),
(4, 204),
(5, 204);

-- --------------------------------------------------------

--
-- Structure de la table `salle`
--

CREATE TABLE `salle` (
  `numSalle` int(11) NOT NULL,
  `nbPlaceTot` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `salle`
--

INSERT INTO `salle` (`numSalle`, `nbPlaceTot`) VALUES
(103, 15),
(104, 15),
(105, 0),
(106, 15),
(107, 15),
(108, 15),
(109, 15),
(110, 15),
(111, 15),
(112, 15),
(201, 15),
(202, 15),
(203, 15),
(204, 15);

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `INE` int(11) NOT NULL,
  `Nom` varchar(50) NOT NULL,
  `Prenom` varchar(50) NOT NULL,
  `Login` varchar(50) NOT NULL,
  `mdpNum` int(100) DEFAULT NULL COMMENT 'mot de passe numérique',
  `mdpNumH` varchar(255) DEFAULT NULL COMMENT 'mot de passe numerique haché',
  `Pass` varchar(50) NOT NULL,
  `PassHash` varchar(100) DEFAULT NULL COMMENT 'mot de passe hashé',
  `droits` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`INE`, `Nom`, `Prenom`, `Login`, `mdpNum`, `mdpNumH`, `Pass`, `PassHash`, `droits`) VALUES
(1, 'NZUMGUENG', 'Samson', 'nzumgues', 2001, '$2y$10$yAiJEASHTPQj1UUmSVpqZerRmX0DT3z9cRLUyO/HBxEjCOcDXUAEi', 'samm', '$2y$10$I7fM.C1PyNZ4QTOlSyTEOeP5ZA5gpwo7.QmQKTSeWgy.yFnujnuTm', 'etudiant'),
(2, 'MORENA', 'Lizanne', 'morenam', 2020, '$2y$10$bfz9gA.fNGL/FY7R3TlVkO8wMKFDxKYGCkPGNWACzcqyLq8fnCe6G', 'cisco', '$2y$10$bKZKaVOp3.Zj5Cixzi3pluCOyBM1KzxP9He3LAV3J6njdgNcOk3Ku', 'etudiant'),
(3, 'TONLEU', 'Ghislain', 'tonleug', 0, NULL, 'dormeur', '$2y$10$H1GfOsxK3TBkQbswlXp4Ou7heSMmMpzcUn2XqHm2rR9f.BmBG7WOa', 'etudiant'),
(4, 'MOUAFO', 'Paul', 'mouafop', 9696, NULL, 'good', '$2y$10$4hpojNFRZkpF7A6/4S5DTO939wA6BDKma4ovQTw2QiyKn4I2XJGzu', 'etudiant'),
(5, 'TCHATCHOU', 'Wilfried', 'tchatchouw', 6969, NULL, 'class', '$2y$10$ZqGTIKuwNhD6ntqE.q2b1O2XqqVkSvNTEk3YRzGZ7HWyybuThlnbW', 'etudiant'),
(6, 'MANKU', 'Heidi', 'mankuh', 2007, NULL, 'secret1', '$2y$10$AWwMKfKmykMJ6pKpqNYv3OulTI2NqJ0Ev6oOJSoOAa5W/jdST3Tu6', 'etudiant'),
(7, 'KAMDAM', 'Fabrice', 'kamdamf', 1234, NULL, '1234', '$2y$10$IvurnyzLUVw7Y9kgagftvetOlMrhbc8AXL6XyI.A08vupbGe9CmfG', 'etudiant'),
(99, 'admin3il', 'administrateur', 'root', 1231, NULL, 'admin', '$2y$10$srb4GyqGHy4J.arLBs/Lc.szzNKT2WP/8WZPNqUq4Cbn.kZsVcdaq', 'admin');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `creneau`
--
ALTER TABLE `creneau`
  ADD PRIMARY KEY (`Madat`,`idc`,`INE`,`numSalle`),
  ADD KEY `idc` (`idc`),
  ADD KEY `INE` (`INE`),
  ADD KEY `numSalle` (`numSalle`);

--
-- Index pour la table `creneau3il`
--
ALTER TABLE `creneau3il`
  ADD PRIMARY KEY (`Id`);

--
-- Index pour la table `disponibilite`
--
ALTER TABLE `disponibilite`
  ADD KEY `disponibilite_Salle_FK` (`id_s`),
  ADD KEY `disponibilite_creneau3il_FK` (`Id_cr`);

--
-- Index pour la table `salle`
--
ALTER TABLE `salle`
  ADD PRIMARY KEY (`numSalle`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`INE`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `creneau3il`
--
ALTER TABLE `creneau3il`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `salle`
--
ALTER TABLE `salle`
  MODIFY `numSalle` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=205;

--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `INE` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `creneau`
--
ALTER TABLE `creneau`
  ADD CONSTRAINT `creneau_ibfk_1` FOREIGN KEY (`idc`) REFERENCES `creneau3il` (`Id`),
  ADD CONSTRAINT `creneau_ibfk_2` FOREIGN KEY (`INE`) REFERENCES `user` (`INE`),
  ADD CONSTRAINT `creneau_ibfk_3` FOREIGN KEY (`numSalle`) REFERENCES `salle` (`numSalle`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
