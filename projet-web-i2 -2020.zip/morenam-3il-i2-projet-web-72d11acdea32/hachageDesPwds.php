<?php
echo password_hash("secret1", PASSWORD_DEFAULT);
try {
    $connect = new PDO("mysql:host=localhost;dbname=3ilreservsalle;charset=utf8", "root", "");
    $connect->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = $connect->query("SELECT mdpNum FROM user");

    $result = $sql->fetch();
    while ($sql->fetch()) {
        $pwdh = password_hash($result['mdpNum'], PASSWORD_DEFAULT);
        $modif = $connect->query("UPDATE user SET mdpNumH='" . $pwdh . "'WHERE mdpNum='" . $result['mdpNum'] . "'");
    }
?>
    <br /><br /><br /><br /><br /><br />
    <center>
        <p class="error"><b>
                <font size="15px">Tous les mots de passes ont été hachés !</font>
            </b></p>
    </center><?php

            } catch (PDOException $er) {
                echo $er;
            }


                ?>