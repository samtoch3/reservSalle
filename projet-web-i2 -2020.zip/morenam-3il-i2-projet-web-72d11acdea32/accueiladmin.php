 <?php
    session_start();
   
    if($_GET['key']==$_SESSION['token']){
    ?>
 

 <!DOCTYPE html>
 <html lang="fr" dir="ltr">

 <head>
     <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
     <title>Salles'Reserv. - Administrateur</title>
     <link rel="shortcut icon" href="pics/0.png">
     <link rel="stylesheet" href="frameworks/bootstrap/css/bootstrap.min.css">
     <link rel="stylesheet" href="frameworks/fontawesome-free/css/all.min.css">
     <link rel="stylesheet" href="style.css">
     <link rel="stylesheet" href="web/Dev web -bootstrap 4.3.1/bootstrap-4.3.1-dist/css/bootstrap.min.css">

     <style>
         body {
             font-family: Arial, Helvetica, sans-serif;
         }

         /* Full-width input fields */
     </style>
 </head>

 <body>
     <header>
         <nav class="navbar navbar-expand-md navbar-dark navbar-right fixed-top">
             <!-- Logo -->
             <a class="navbar-brand" href="accueil.php">
                 <img src="pics/pic1.png" alt="Accueil" title="Accueil" width="110px" height="65px">
                 <img src="pics/0.png" alt="Accueil" title="Accueil" width="40px" height="35px">
             </a>

             <!-- Toggler/collapsibe Button -->
             <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
                 <span class="navbar-toggler-icon"></span>
             </button>

             <!-- Navbar links -->
             <div class="collapse navbar-collapse" id="collapsibleNavbar">
                 <ul class="navbar-nav justify-content-end">
                     <li class="nav-item active">
                         <a class="nav-link" href="accueiladmin.php">
                             <i class="fas fa-home"></i>
                             Accueil</a>
                     </li>
                     <li class="nav-item">
                         <a class="nav-link" href="listetreserv.php">
                             <i class="fas fa-sign-in-alt"></i>
                             Liste des étudiants ayant effectué(e)s une reservation</a>
                     </li>
                     <li class="nav-item">
                         <a class="nav-link" href="listesallesresrv.php">
                             <i class="fas fa-clone"></i>
                             Liste des salles reservées</a>
                     </li>
                     <li class="nav-item">
                         <a class="nav-link" href="listesalles.php">
                             <i class="fas fa-list"></i>
                             Liste de toutes les salles LS</a>
                     </li>
                     <li class="nav-item">
                         <a class="nav-link" href="listeetudiant.php">
                             <i class="fas fa-user"></i>
                             Liste des étudiants</a>
                     </li>
                     <li class="nav-item">
                         <a class="nav-link" href="deconnect.php">
                             <i class="fas fa-sign-out-alt"></i>
                             Se deconnecter</a>
                     </li>
                 </ul>
             </div>
             <i class="nav-link">
                 <h2 class="text-theme-colored-white font-20">Bonjour <b><?php echo $_SESSION['prenom'] ?></b>.</h2>
             </i>
         </nav>
     </header>

     <section>
         <div class="jumbotron jumbotron-fluid">
             <center>
                 <div class="container">
                     <p>
                         <h2><b>Salles'Reserv.</b>, pour faciliter l'accès aux salles libre services de l'école aux étudiants !</h2>
                     </p>
                     <p>
                         <h3>Des milliers d'étudiants reservent facilement et rapidement des salles pour leurs travaux en solitaire ou de groupe. </h3></br>
                     </p>
                     <p>
                         <h3>Administrateur, gérez leurs reservation.</h3>
                     </p>
                     <button type="button" class="btn">
                         <i class="fas fa-edit"></i>
                         <a href="#">Liste des reservations à venir</a>
                     </button>
                 </div>
             </center>
         </div>
         <br /><br /><br /><br /><br />
     </section>


     <footer id="footer" class="fixed-bottom">
         <a href="#">A propos de nous</a> |
         <a href="#">Guide & Assistance</a> |
         <a href="#">Laissez nous un commentaire !</a>
         <p style="text-align:center !important;">
             <a href="#">Mentions Légales</a> - © Sept 2020 - <a href="#">Politique & confidentialité</a>

             <div class="footer-items-groups">
                 <div class="footer-items">
                     <a href="https://www.facebook.com"><i class="fab fa-facebook-f" class="footer-item"></i></a>
                     <a href="https://www.twiter.com"><i class="fab fa-twitter" class="footer-item"></i></a>
                     <a href="https://www.youtube.com"><i class="fab fa-youtube" class="footer-item"></i></a>
                     <a href="https://www.instagram.com"><i class="fab fa-instagram" class="footer-item"></i></a>
                     <a href="https://www.google.com"><i class="fab fa-google" class="footer-item"></i></a>
                     <a href="https://www.pinterest.com"><i class="fab fa-pinterest" class="footer-item"></i></a>
                     <a href="https://www.linkedin.com"><i class="fab fa-linkedin" class="footer-item"></i></a>
                     <a href="https://www.whatsapp.com"><i class="fab fa-whatsapp" class="footer-item"></i></a>
                 </div>
             </div>
         </p>
     </footer>
     <script src="frameworks/jquery/jquery.min.js"></script>

     <script src="frameworks/bootstrap/js/bootstrap.bundle.min.js"></script>

     <script src="frameworks/jquery-easing/jquery.easing.min.js"></script>
 </body>

 </html>
 <?php } else {
	header('Location:index.php');
}
?>