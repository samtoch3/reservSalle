<?php
session_start();
?>


<!DOCTYPE html>
<html lang="fr" dir="ltr">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <meta name="description" content="Connexion à votre compte unepetition.fr petition en ligne gratuite ">
  <meta name="keywords" content="creer petition, petition, lancer petition, petition du web, je signe, je lance, une petition ">

  <title>Salles'Reserv. - Reserver un salle</title>

  <link rel="shortcut icon" href="pics/pic3.png">
  <link rel="stylesheet" href="frameworks/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="frameworks/fontawesome-free/css/all.min.css">
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="web/Dev web -bootstrap 4.3.1/bootstrap-4.3.1-dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="fonts/font-awesome.min.css">
  <style>
    body {
      font-family: Arial, Helvetica, sans-serif;
    }

    /* Full-width input fields */
  </style>
</head>

<body>
  <header>
    <nav class="navbar navbar-expand-md navbar-dark navbar-right fixed-top">
      <!-- Logo -->
      <a class="navbar-brand" href="accueil.php">
        <img src="pics/pic1.png" alt="Accueil" title="Accueil" width="110px" height="65px">
      </a>

      <!-- Toggler/collapsibe Button -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>

      <!-- Navbar links -->
      <div class="collapse navbar-collapse" id="collapsibleNavbar">
        <ul class="navbar-nav justify-content-end">
          <li class="nav-item">
            <a class="nav-link" href="accueil.php">
              <i class="fas fa-home"></i>
              Accueil</a>
          </li>
          <li class="nav-item active">
            <a class="nav-link" href="reservation.php">
              <i class="fas fa-edit"></i>
              Reserver une salle</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="viewReservation.php">
              <i class="fas fa-clone"></i>
              Voir mes reservation</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="planningSalle.php">
              <i class="fas fa-list"></i>
              Planning des salles LS</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" onclick="document.getElementById('id01').style.display='block'" style="width:auto;">
              <i class="fas fa-user"></i>
              Mon profil</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="deconnect.php">
              <i class="fas fa-sign-out-alt"></i>
              Se deconnecter</a>
          </li>
        </ul>
      </div>
      <i class="nav-link">
        <h2 class="text-theme-colored-white font-20">Bonjour <b><?php echo $_SESSION['prenom'] ?></b>.</h2>
      </i>
    </nav>
  </header>

  <section>
    <div class="jumbotron jumbotron-fluid">
      <div class="container">
        <div class="row">


          <table>
            <tr>
              <td>

              </td>
              <td>

              </td>
            </tr>
          </table>


          <div class="col-md-6 col-md-push-3">
            <br>
            <h4 class="text-gray mt-0 pt-5" align="center"> Reserver une salle</h4>
            <hr>
            <form name="login-form" class="clearfix" action="insert.php" method="post">
              <input type="hidden" name="token" value="ab834ec23bb3d43abb05ac4ee12dfeer31aab7589fc1">
              <div class="row" align="center">
                <div class="form-group col-md-12">
                  <label>DATE : </label>
                  <input name="Madat" type="date" value="date.now()">
                </div>
              </div>
              <div class="row" align="center">
                <div class="form-group col-md-12">
                  <label>SALLE : </label>

                  <select name="numSalle">
                    <option>103
                    <option>104
                    <option>105
                    <option>106
                    <option>107
                    <option>108
                    <option>109
                    <option>110
                    <option>111
                    <option>112
                    <option>201
                    <option>202
                    <option>203
                    <option>204
                  </select>


                </div>
              </div>
              <!--
              <div class="row" align="center">
                <div class="form-group col-md-11">
                  <label >CRENEAU : </label>
                  <select  name="nom" size="1">
                  <option>8h30-10h
                  <option>10h30-12h
                  <option>13h30-15h
                  <option>15h15-16h45
                  <option>17h-18h30
                  </select>
                  
                </div>
              </div>
              -->

              <div class="row" align="center">
                <div class="form-group col-md-11">

                  <?php
                  try {
                    $bd = new PDO("mysql:host=localhost;dbname=3ilreservsalle;charset=utf8", "root", "");
                    $bd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                    $req = $bd->query("SELECT heure_deb, heure_fin FROM creneau3il");
                  } catch (Exception $e) {
                    echo $e;
                  }
                  ?>
                  <table>
                    <tr>
                      <td colspan="2" align="center">CRENEAU</td>
                    </tr>
                    <tr>
                      <td><input placeholder="DEBUT" name="heure_deb" type="time" value="08:30"> -</td>
                      <td>- <input placeholder="FIN" name="heure_fin" type="time" value="10:00"></td>
                    </tr>
                  </table>
                </div>
              </div>




              <div class="form-group pull-right mt-10">
                <button type="submit" class="btn btn-gray btn-sm">Valider votre reservation</button>
              </div>
              <div class="clear text-center pt-10">
                <a class="text-theme-colored font-weight-600 font-14" href="viewReservation.php">Annuler une reservation?</a>
              </div>

            </form>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section>
    <div id="id01" class="modal">

      <form class="modal-content animate" action="#" method="POST">
        <div class="imgcontainer">
          <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Quitter">&times;</span>
        </div>

        <div class="container">
          <div>
            <br />
            <table>
              <tr>
                <td align="right" width="50%" colsspan="2"><img src="pics/pic4.png" width="100px" height="100px"></td>
                <td></td>
              </tr>
              <tr>
                <td><b>INE : </b></td>
                <td><b> D87U3iLi2E00<?php echo $_SESSION['ine'] ?></b></td>
              </tr>
              <tr>
                <td><b>Prenom : </b></td>
                <td><b> <?php echo $_SESSION['prenom'] ?></b></td>
              </tr>
              <tr>
                <td><b>Nom : </b></td>
                <td><b> <?php echo $_SESSION['nom'] ?></b></td>
              </tr>
              <tr>
                <td><b>Login : </b></td>
                <td><b> <?php echo $_SESSION['login'] ?>@3il.fr</b></td>
              </tr>
            </table>
          </div>
      </form>
    </div>



    <script>
      // Get the modal
      var modal = document.getElementById('id01');

      // When the user clicks anywhere outside of the modal, close it
      window.onclick = function(event) {
        if (event.target == modal) {
          modal.style.display = "none";
        }
      }
    </script>
  </section>

  <footer id="footer" class="fixed-bottom">
    <a href="#">A propos de nous</a> |
    <a href="#">Guide & Assistance</a> |
    <a href="#">Laissez nous un commentaire !</a>
    <p style="text-align:center !important;">
      <a href="#">Mentions Légales</a> - © Sept 2020 - <a href="#">Politique & confidentialité</a>
      <div class="footer-items-groups">
        <div class="footer-items">
          <a href="https://www.facebook.com"><i class="fab fa-facebook-f" class="footer-item"></i></a>
          <a href="https://www.twitter.com"><i class="fab fa-twitter" class="footer-item"></i></a>
          <a href="https://www.youtube.com"><i class="fab fa-youtube" class="footer-item"></i></a>
          <a href="https://www.instagram.com"><i class="fab fa-instagram" class="footer-item"></i></a>
          <a href="https://www.google.com"><i class="fab fa-google" class="footer-item"></i></a>
          <a href="https://www.pinterest.com"><i class="fab fa-pinterest" class="footer-item"></i></a>
          <a href="https://www.linkedin.com"><i class="fab fa-linkedin" class="footer-item"></i></a>
          <a href="https://www.whatsapp.com"><i class="fab fa-whatsapp" class="footer-item"></i></a>
        </div>
      </div>
    </p>
  </footer>
</body>

</html>